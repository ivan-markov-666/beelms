DESTROYED is a font created by Matt Mars (a.k.a. MARSUG, a.k.a. WESHER) in 2024.
It supports both Latin and Cyrillic characters.
This font was first used in the music album WESHER – "ICOMBO 2 Remix" and also appeared in other music releases by MARSUG.

You are free to share and adapt this font for any purpose, including commercial use, provided that you give appropriate credit to the author.
Font "DESTROYED" by Matt Mars — CC BY 4.0