Hello,

Thank you for purchasing and using Raela Grotesque.


- How to Enable OpenType Features in Word, Photoshop and Illustrator
  https://medialoot.com/blog/how-to-enable-opentype-features-in-word-photoshop-and-illustrator/

- How to Using Special Characters
  https://helpx.adobe.com/illustrator/using/special-characters.html


Diki Pradipta Tri Atmojo ^
Pradipta Creative x Lettertype Studio
