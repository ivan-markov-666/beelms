# FAQ
Perguntas frequentes sobre nossa plataforma.
![Visão geral do FAQ](faq-diagram.png)
![Painel](testImage.jpg)
