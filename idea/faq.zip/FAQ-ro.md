# FAQ
Întrebări frecvente despre platforma noastră.
![Prezentare generală FAQ](faq-diagram.png)
![Panou de control](testImage.jpg)
