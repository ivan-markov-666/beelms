# FAQ
Häufig gestellte Fragen zu unserer Plattform.
![FAQ-Übersicht](faq-diagram.png)
![Dashboard](testImage.jpg)
