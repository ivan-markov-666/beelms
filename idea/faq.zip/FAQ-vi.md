# FAQ
Câu hỏi thường gặp về nền tảng của chúng tôi.
![Tổng quan FAQ](faq-diagram.png)
![Bảng điều khiển](testImage.jpg)
