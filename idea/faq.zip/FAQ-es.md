# FAQ
Preguntas frecuentes sobre nuestra plataforma.
![Resumen de FAQ](faq-diagram.png)
![Panel de control](testImage.jpg)
