# FAQ
플랫폼에 대한 자주 묻는 질문입니다.
![FAQ 개요](faq-diagram.png)
![대시보드](testImage.jpg)
