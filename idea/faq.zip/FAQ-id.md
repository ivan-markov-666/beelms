# FAQ
Pertanyaan yang sering diajukan tentang platform kami.
![Ringkasan FAQ](faq-diagram.png)
![Dasbor](testImage.jpg)
