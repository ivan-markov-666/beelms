# FAQ
Často kladené otázky o naší platformě.
![Přehled FAQ](faq-diagram.png)
![Ovládací panel](testImage.jpg)
