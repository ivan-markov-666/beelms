# FAQ
Frequently Asked Questions about our platform.
![FAQ Overview](faq-diagram.png)
![Dashboard](testImage.jpg)
