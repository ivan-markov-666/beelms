# FAQ
Domande frequenti sulla nostra piattaforma.
![Panoramica FAQ](faq-diagram.png)
![Dashboard](testImage.jpg)
