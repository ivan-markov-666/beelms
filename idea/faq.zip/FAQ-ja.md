# FAQ
プラットフォームに関するよくある質問。
![FAQ概要](faq-diagram.png)
![ダッシュボード](testImage.jpg)
