# FAQ
Często zadawane pytania o naszą platformę.
![Przegląd FAQ](faq-diagram.png)
![Panel kontrolny](testImage.jpg)
