# FAQ
Questions fréquemment posées sur notre plateforme.
![Aperçu FAQ](faq-diagram.png)
![Tableau de bord](testImage.jpg)
2
