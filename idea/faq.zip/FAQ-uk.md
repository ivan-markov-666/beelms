# FAQ
Часті питання про нашу платформу.
![Огляд FAQ](faq-diagram.png)
![Панель керування](testImage.jpg)
