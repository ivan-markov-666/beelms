# FAQ
Platformumuz hakkında sık sorulan sorular.
![FAQ Genel Bakış](faq-diagram.png)
![Kontrol Paneli](testImage.jpg)
