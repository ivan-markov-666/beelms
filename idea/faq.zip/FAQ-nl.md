# FAQ
Veelgestelde vragen over ons platform.
![FAQ-overzicht](faq-diagram.png)
![Dashboard](testImage.jpg)
